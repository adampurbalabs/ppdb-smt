<!-- jQuery -->
<?php include('../ro-index/ro-copyright.php'); ?>  
<script src="../assets/vendor/jquery/jquery.min.js"></script>
<script src="../assets/vendor/bootstrap/js/bootstrap.min.js"></script>
 <!--Date Picke -->
<script src="../assets/vendor/datepicker/js/bootstrap-datepicker.js"></script>
  <!-- Date Picker -->
<script type="text/javascript">
 $(document).ready(function () {
$('.tanggal').datepicker({
format: "yyyy-mm-dd",
autoclose:true
           });
            });
        </script>
</div>
</div>
  </body>
</html>
