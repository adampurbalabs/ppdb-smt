<html>
<head>
<meta http-equiv="refresh" content="0;url=index/index.php">
<title>Redirecting</title>
<script language="javascript">
    window.location.href = "ro-index/"
</script>
</head>
<body>
Go to <a href="ro-index/index.php">Home</a>
</body>
</html>
