<section class="col-sm-12">
<div class="page-header"><h3>MAAF PENDAFTARAN SUDAH DITUTUP</h3></div>

        <p>Jika sudah mendaftar, silahkan <a href="bukti-pendaftaran">cetak bukti pendaftaran</a> atau <a href="kartu-peserta">kartu peserta</a></p>

</section>