
<footer class="footer container">
	
<section class="col-sm-12" style="margin-top: 50px;">
<div class="col-lg-10 col-lg-offset-1 text-center">
<br>
<ul class="list-inline">
<li>
<a href="https://www.facebook.com/root93.co.id/" target="_blank"><i class="fa fa-facebook fa-fw fa-2x"></i></a>
</li>
<li>
<a href="https://plus.google.com/u/0/+AhmadZaelani-r93" target="_blank"><i class="fa fa-google fa-fw fa-2x"></i></a>
</li>
<li>
<a href="https://www.youtube.com/channel/UCNqYyG7I_uHC7JRxi-jZdtQ" target="_blank"><i class="fa fa-youtube fa-fw fa-2x"></i></a>
</li>
</ul>
<hr class="medium">
<p class="text-muted" style="font-size: 12px;">Copyright &copy; IT Development <?php echo "$row[nama_sekolah]";?> - Proudly powered by <a href="https://www.root93.co.id" target="_blank">APLabs</a></p>
</div>
</section>
</footer>
