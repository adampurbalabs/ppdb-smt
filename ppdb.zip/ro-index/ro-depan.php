
<section class="col-sm-12">
<div class="jumbotron">
        <h2>Selamat Datang di Halaman <?php echo "$row[nama_sekolah]";?></h2>
        <p style="font-size: 18px;">Halaman ini merupakan  resmi Pendaftaran Peserta Didik Baru  <?php echo "$row[nama_sekolah]";?>.
        <br><br>Alur Pendaftaran <ul>
        <li>Daftarkan diri anda melalui tombol "Daftar" yang berada di menu kiri atas pada laman ini </li>
        <li>Calon Peserta Didik setelah itu melakukan Cetak Bukti Pendaftaran dengan klik "Print" Pilih "Bukti Pendaftaran" (jika menggunakan Smartphone boleh ScreenShoot Bukti pendaftarannya)</li>
        <li>Setelah itu Calon Peserta Didik melakukan Print Kartu Peserta (jika menggunakan Smartphone boleh ScreenShoot Kartu Peserta)</li>
        <li>Peserta didik melakukan pembayaran pendaftaran dan mengirimkan bukti transfer pendaftaran dengan mengirimkan Kartu Peserta dan hasil bukti transfer ke No. Whatsapp 0812 1183 3123.</li>
        <li>Tunggu pendaftaran anda akan di verfikasi setelah anda mengirimkan bukti transfer, untuk melihat status pendaftaran anda silahkan klik "Pengumuman" pada menu kiri atas lalu masukkan NISN/NIK anda.</li></p>
</div>
<div class="jumbotron">
        <h2>Info Pendaftaran</h2>
        <p>Pendaftaran dimulai pada bulan November 2019 sampai dengan Juli 2020<font size=2px>
        	<br> >> Calon Peserta Didik dapat melakukan konsultasi melalui No Wahatsapp diatas untuk melakukan pendaftaran</p>

        <p>Info Gelombang:<font size=2px>
        	<br> >> Gelombang 1 :
        	<br> >> Gelombang 2 :
        	<br> >> Gelombang 3 :
        	<br> >> Gelombang 4 :
        </font></p>

        <p>Info Pendaftaran:<font size=2px>
        	<br> >> Setelah melakukan pendaftaran peserta didik harap melakukan pembayaran pendaftaran sebesar Rp. 150.000,- dan bukti transfer harap di kirimkan melalui No Whatsapp <?php echo "$row[telephone_sekolah]";?> untuk melakukan update verifikasi.
        </font></p>

</div>
</section>


